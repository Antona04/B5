<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <h1>CD Katalog</h1>
    <nav>
      <ul>
        <li><a href="index.php">Katalog</a></li>
        <li><a href="uputstvo.html">Koristnicko uputstvo</a></li>
      </ul>
    </nav>
    <form action="index.php" method="post">
      <div>
        <label for="izvodjac">Izvodjac:</label>
        <input type="text" id="izvodjac" name="izvodjac" value="<?php if(isset($_POST['izvodjac']) === true && $_POST['izvodjac'] != '') echo $_POST['izvodjac']; ?>"/>
      </div>
      <div>
        <label for="album">Naziv albuma:</label>
        <input type="text" id="album" name="album" value="<?php if(isset($_POST['album']) === true && $_POST['album'] != '') echo $_POST['album']; ?>"/>
      </div>
      <div>
        <label for="zanr">Zanr:</label>
        <select id="zanr" name="zanr" value="<?php if(isset($_POST['zanr']) === true && $_POST['zanr'] != '') echo $_POST['zanr']; ?>">
          <option value=""></option>
          <option value="pop">Pop</option>
          <option value="rock">Rock</option>
          <option value="etno">Etno</option>
          <option value="folk">Folk</option>
          <option value="punk">Punk</option>
          <option value="punk-rock">Punk-Rock</option>
        </select>
      </div>
      <div>
        <label for="god">Godina izdanja:</label>
        <select id="god" name="god" value="<?php if(isset($_POST['god']) === true && $_POST['god'] != '') echo $_POST['god']; ?>">
          <option value=""></option>
          <option value="2007">2007</option>
          <option value="2008">2008</option>
          <option value="2009">2009</option>
          <option value="2010">2010</option>
        </select>
      </div>
      <div>
        <label for="kuca">Izdavacka kuca:</label>
        <input type="text" id="kuca" name="kuca" value="<?php if(isset($_POST['kuca']) === true && $_POST['kuca'] != '') echo $_POST['kuca']; ?>"/>
      </div>
      <input type="submit"  class="searchbutton" value="Trazi" />
    </form>

    <?php

include(dirname(__FILE__) . '/action_page.php');

?>

    
    <footer>&#169; Klub kolekcionar</footer>
  </body>
</html>
