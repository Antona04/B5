<?php

echo "<pre>";

if(isset($_POST['izvodjac']) === true && $_POST['izvodjac'] != ''){
    $trazi_izvodjac = strtolower($_POST['izvodjac']); 
}else{
    $trazi_izvodjac = false;
}

if(isset($_POST['album']) === true && $_POST['album'] != ''){
    $trazi_album = strtolower($_POST['album']); 
}else{
    $trazi_album = false;
}

if(isset($_POST['god']) === true && $_POST['god'] != ''){
    $trazi_godinu = strtolower($_POST['god']); 
}else{
    $trazi_godinu = false;
}

if(isset($_POST['kuca']) === true && $_POST['kuca'] != ''){
    $trazi_kucu = strtolower($_POST['kuca']); 
}else{
    $trazi_kucu = false;
}


if(isset($_POST['zanr']) === true && $_POST['zanr'] != ''){
    $trazi_zanr = $_POST['zanr']; 
}else{
    $trazi_zanr = false;
}


$katalog_array = array();


$handle = fopen("katalog.txt", "r");


while (($line = fgets($handle)) !== false) {

    $tmp_line_array = explode('|', $line);

    $katalog_array[] = array_map(function ($item_of_array) {
        return trim($item_of_array); 
    }, $tmp_line_array);
}


fclose($handle);

foreach ($katalog_array as $key => $katalog_line) {

    
    if($trazi_izvodjac !== false){
        if( strpos(strtolower($katalog_line['0']), $trazi_izvodjac) === false){
            unset($katalog_array[$key]);
            continue;
        } 
    }

    
    if($trazi_album !== false){
        if( strpos(strtolower($katalog_line['1']), $trazi_album) === false){
            unset($katalog_array[$key]);
            continue;
        } 
    }

    
    if($trazi_zanr !== false){
        if( strtolower($katalog_line['2']) !== $trazi_zanr){
            unset($katalog_array[$key]);
            continue;
        } 
    }

    if($trazi_godinu !== false){
        if( strtolower($katalog_line['3']) !== $trazi_godinu){
            unset($katalog_array[$key]);
            continue;
        } 
    }

    if($trazi_kucu !== false){
        if( strtolower($katalog_line['4']) !== $trazi_kucu){
            unset($katalog_array[$key]);
            continue;
        } 
    }

    
}

echo "<style>
table, th, td {
    border: 1px solid black;
}
</style>";

echo "<table>";
foreach ($katalog_array as $row => $values) {
    echo "<tr>";
    foreach ($values as $value) {
        echo "<td>" . $value . "</td>";
    }
    echo "</tr>";
}
echo "<table>";
exit();