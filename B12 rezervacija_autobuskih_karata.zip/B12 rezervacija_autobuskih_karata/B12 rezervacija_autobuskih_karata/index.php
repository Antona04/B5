<?php
// Povezivanje sa bazom
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "autobus";

$conn = new mysqli($servername, $username, $password, $dbname);

// Provera konekcije
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Rezervacija autobuskih karata</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <h1>Rezervacija autobuskih karata</h1>
    <nav>
      <ul>
        <li><a href="index.php">Pocetna</a></li>
        <li><a href="oautoru.html">O Autoru</a></li>
        <li><a href="uputstvo.html">Uputstvo</a></li>
      </ul>
    </nav>
    <h3>Prikaz sedista autobusa:</h3>
    <div class="sadrzaj">

    
     

      <div class="seat-layout">
      <?php
$sql = "SELECT BrojSedista, Rezervacija FROM res";
$result = $conn->query($sql);


$reserved_seats = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if ($row["Rezervacija"] == 1) {
            $reserved_seats[] = $row["BrojSedista"];
        }
    }
}

echo '<div class="seat-layout">';
echo '<div class="seat-column">';
for ($i = 2; $i <= 50; $i += 4) {
    if (in_array($i, $reserved_seats)) {
        echo '<div class="seat reserved" data-seat-number="' . $i . '">' . $i . '</div>';
    } else {
        echo '<div class="seat" data-seat-number="' . $i . '">' . $i . '</div>';
    }
}
echo '</div>';

echo '<div class="seat-column">';
for ($i = 3; $i <= 51; $i += 4) {
    if (in_array($i, $reserved_seats)) {
        echo '<div class="seat reserved" data-seat-number="' . $i . '">' . $i . '</div>';
    } else {
        echo '<div class="seat" data-seat-number="' . $i . '">' . $i . '</div>';
    }
}
echo '</div>';

echo '<div class="seat-column2"></div>'; //razmak izmedju sedista, u css-u width samo

echo '<div class="seat-column">';
for ($i = 4; $i <= 52; $i += 4) {
    if (in_array($i, $reserved_seats)) {
        echo '<div class="seat reserved" data-seat-number="' . $i . '">' . $i . '</div>';
    } else {
        echo '<div class="seat" data-seat-number="' . $i . '">' . $i . '</div>';
    }
}
echo '</div>';

echo '<div class="seat-column">';
for ($i = 5; $i <= 53; $i += 4) {
    if (in_array($i, $reserved_seats)) {
        echo '<div class="seat reserved" data-seat-number="' . $i . '">' . $i . '</div>';
    } else {
        echo '<div class="seat" data-seat-number="' . $i . '">' . $i . '</div>';
    }
}
echo '</div>';
echo '</div>';


?>

</div>
      <form
        class="reservation-form"
        action="submit_reservation.php"
        method="POST"
      >
        <div class="form-row">
          <label for="seat-number">Broj sedista:</label>
          <input
            type="text"
            id="seat-number"
            name="seat_number"
            required
            readonly
          />
        </div>
        <div class="form-row">
          <label for="first-name">Ime i prezime:</label>
          <input type="text" id="first-name" name="first_name" required />
        </div>
        <div class="form-row">
          <label for="email">E-mail:</label>
          <input type="email" id="email" name="email" required />
        </div>
        <button type="submit">Posalji</button>
      </form>
    </div>
    <footer>&#169; Autobuska stanica</footer>
    <script src="script.js"></script>
  </body>
</html>

