<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "autobus";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$seat_number = $_POST['seat_number'];
$first_name = $_POST['first_name'];
$email = $_POST['email'];

$sql = "UPDATE res SET Rezervacija = 1 WHERE BrojSedista = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $seat_number);
$stmt->execute();

$stmt->close();
$conn->close();

header("Location: index.php");
exit();
?>