<?php

echo "<pre>";

if(isset($_POST['ime']) === true && $_POST['ime'] != ''){
    $trazi_ime = strtolower($_POST['ime']); 
}else{
    $trazi_ime = false;
}

if(isset($_POST['prezime']) === true && $_POST['prezime'] != ''){
    $trazi_prezime = strtolower($_POST['prezime']); 
}else{
    $trazi_prezime = false;
}

if(isset($_POST['adresa']) === true && $_POST['adresa'] != ''){
    $trazi_adresu = strtolower($_POST['adresa']); 
}else{
    $trazi_adresu = false;
}

if(isset($_POST['email']) === true && $_POST['email'] != ''){
    $trazi_email = strtolower($_POST['email']); 
}else{
    $trazi_email = false;
}


if(isset($_POST['brojtelefona']) === true && $_POST['brojtelefona'] != ''){
    $trazi_brojtelefona = $_POST['brojtelefona']; 
}else{
    $trazi_brojtelefona = false;
}

if(isset($_POST['mesto']) === true && $_POST['mesto'] != ''){
    $trazi_mesto = strtolower($_POST['mesto']); 
}else{
    $trazi_mesto = false;
}


$imenik_array = array();


$handle = fopen("imenik.txt", "r");


while (($line = fgets($handle)) !== false) {

    $tmp_line_array = explode('|', $line);

    $imenik_array[] = array_map(function ($item_of_array) {
        return trim($item_of_array); 
    }, $tmp_line_array);
}


fclose($handle);

foreach ($imenik_array as $key => $imenik_line) {

    
    if($trazi_ime !== false){
        if( strpos(strtolower($imenik_line['1']), $trazi_ime) === false){
            unset($imenik_array[$key]);
            continue;
        } 
    }

    
    if($trazi_prezime !== false){
        if( strpos(strtolower($imenik_line['2']), $trazi_prezime) === false){
            unset($imenik_array[$key]);
            continue;
        } 
    }

    
    if($trazi_adresu !== false){
        if( strtolower($imenik_line['3']) !== $trazi_adresu){
            unset($imenik_array[$key]);
            continue;
        } 
    }

    if($trazi_email !== false){
        if( strtolower($imenik_line['6']) !== $trazi_email){
            unset($imenik_array[$key]);
            continue;
        } 
    }

    if($trazi_mesto !== false){
        if( strtolower($imenik_line['4']) !== $trazi_mesto){
            unset($imenik_array[$key]);
            continue;
        } 
    }

    
    if($trazi_brojtelefona !== false){
        if( $imenik_line['5'] !== $trazi_brojtelefona){
            unset($imenik_array[$key]);
            continue;
        } 
    }

}

echo "<style>
table, th, td {
    border: 1px solid black;
}
</style>";

echo "<table>";
foreach ($imenik_array as $row => $values) {
    echo "<tr>";
    foreach ($values as $value) {
        echo "<td>" . $value . "</td>";
    }
    echo "</tr>";
}
echo "<table>";
exit();