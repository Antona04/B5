<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Document</title>
</head>
<body>
    <div class="navigacija">
        <h1 class="naslov1">Zadatak 6</h1>
        <h2 class="naslov2">Telefonski imenik</h2>
    </div>
    <form action="imenik.php" method="post">
        <label for="ime">Ime:</label>
        <input type="text" id="ime" name="ime" class="ime" 
            value="<?php if(isset($_POST['ime']) === true && $_POST['ime'] != '') echo $_POST['ime']; ?>"><br>
        <label for="prezime">Prezime:</label>
        <input type="text" id="prezime" name="prezime" class="prezime" 
            value="<?php if(isset($_POST['prezime']) === true && $_POST['prezime'] != '') echo $_POST['prezime']; ?>"><br>
        <label for="adresa">Adresa:</label>
        <input type="text" id="adresa" name="adresa" class="adresa" 
        value="<?php if(isset($_POST['adresa']) === true && $_POST['adresa'] != '') echo $_POST['adresa']; ?>"  ><br>
        <label for="mesto">Mesto:</label>
        <select name="mesto" id="mesto">
            <option value=""></option>
            <option value="Nis">Nis</option>
            <option value="Beograd">Beograd</option>
        </select><br>
        <label for="brojtelefona">Broj telefona:</label>
        <input type="text" id="brojtelefona" name="brojtelefona" class="brojtelefona" 
        value="<?php if(isset($_POST['brojtelefona']) === true && $_POST['brojtelefona'] != '') echo $_POST['brojtelefona']; ?>"><br>
         
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" class="email" ><br>
        <input type="submit" class="searchbutton"  value="Traži">
    </form> 
    <div class="navigacija2">
        <h3>Elektrotehnicka skola "Nikola Tesla" Nis</h3>
        <a class="a1" href="vazni_telefoni.html">Vazni telefoni</a>
        <a class="a2" href="imenik.php">Pocetna</a>
        <a class="a3" href="o_autoru.html">O autoru</a>
        </div>
    <?php

        include(dirname(__FILE__) . '/action_page.php');

    ?>
        
</body>
</html>